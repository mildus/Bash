from pcs.settings_default import *
service_binary = "/usr/sbin/service"
pengine_binary = "/usr/lib/pacemaker/pengine"
crmd_binary = "/usr/lib/pacemaker/crmd"
cib_binary = "/usr/lib/pacemaker/cib"
stonithd_binary = "/usr/lib/pacemaker/stonithd"
pcsd_exec_location = "/usr/share/pcsd/"
sbd_config = "/etc/default/sbd"
chkconfig_binary = "/usr/sbin/update-rc.d"
