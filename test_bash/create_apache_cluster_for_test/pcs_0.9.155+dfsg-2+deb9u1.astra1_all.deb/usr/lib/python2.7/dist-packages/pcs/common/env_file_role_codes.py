from __future__ import (
    absolute_import,
    division,
    print_function,
    unicode_literals,
)

BOOTH_CONFIG = "BOOTH_CONFIG"
BOOTH_KEY = "BOOTH_KEY"
